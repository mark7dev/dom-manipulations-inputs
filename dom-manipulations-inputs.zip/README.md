# DOM Manipulations - Inputs

## Setup
1 -- navigate to your `assignments` directory:
```
cd ~/Muktek/assignments
```

2 -- Create the project folder
```
mkdir dom-manipulations-inputs
cd dom-manipulations-inputs
```

3 -- Download the `.zip` file, move it to your `dom-manipulations-inputs` folder, and unzip it:

https://github.com/muktek/assignment--dom-manipulations-basics/blob/master/assignment-dom-manipulations-events.zip


4 -- Complete the tasks outlined in the assignment. All of your work will be in the `main.js` file.
